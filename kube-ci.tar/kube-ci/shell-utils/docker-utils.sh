#!/bin/sh

. $KUBE_CI_PATH/shell-utils/screen-utils.sh

#############################################################################################
##                                  BUILD DOCKER
#############################################################################################
DockerUtils.buildDocker()
{
    imageName=$1
    buildCounter=$2
    folder=$3
    ScreenUtils.separateLine
    echo "[BUILD] Docker -> $imageName"
    echo "[BUILD] Docker folder -> $folder"
    echo "[BUILD] Docker home-> $KUBE_CI_PATH"
    echo "[BUILD] Docker version-> $buildCounter"

    docker build -t $imageName:$buildCounter -f $KUBE_CI_PATH/$folder/Dockerfile --build-arg folder=$folder $KUBE_CI_PATH
}
#############################################################################################
##                                  PUSH DOCKER
#############################################################################################
DockerUtils.pushDocker()
{
    imageName=$1
    buildCounter=$2
    ScreenUtils.separateLine
    echo "[PUSH] Docker -> $imageName"
    docker push $imageName:$buildCounter
}

#############################################################################################
##                                  DEPLOY DOCKER
############################################################################################
DockerUtils.deployDocker()
{
    imageName=$1
    buildCounter=$2
    deploymentName=$3
    podName=$4
    ScreenUtils.separateLine
    echo "[DEPLOY] Docker -> $imageName"
    echo "kubectl set image deployments/$deploymentName $podName=$imageName:$buildCounter  --namespace=default"
}

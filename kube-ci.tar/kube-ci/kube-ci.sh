#!/usr/bin/env bash
for i in "$@"
do
case $i in
    -p=*|--projectId=*)
    export PROJECT_ID="${i#*=}"
    ;;
    -bi=*|--buildIncrement=*)
    export BUILD_INCREMENT="${i#*=}"
    ;;
    -h|--help)
    HELP=1
    ;;
    -b|--build)
    BUILD=1
    ;;
    -d|--deploy)
    DEPLOY=1
    ;;
esac
done

export KUBE_CI_PATH=$(dirname .)

if [ -z "$HELP" ] || [ -z $@ ]
then
    read -r -d '' help << EOM
    Available options are:
    -p (--projectId) GOOGLE CLOUD PROJECT ID
    -bi (--buildIncrement) BUILD INCREMENT
    -b (--build) To build your application
    -d (--deploy) To deploy your application
EOM
    echo "${help}"
fi

if [ -z "$BUILD" ]
then
   echo "BUILD"
   bash $KUBE_CI_PATH/build/sources.sh
   bash $KUBE_CI_PATH/docker/docker.sh
fi

if [ -z "$DEPLOY" ]
then
    echo "DEPLOY"
    bash $KUBE_CI_PATH/helm/helm-apply.sh
    bash $KUBE_CI_PATH/kubernetes/kubectl-apply.sh
fi

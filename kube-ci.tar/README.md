# kube-ci
ci bridge between kubernetes and Gitlab

## How to use it
```
wget 
tar -xf kube-ci.tar 
YOUR_INSTALLATION_PATH=/Applications/
mv kube-ci.tar $YOUR_INSTALLATION_PATH/
```

### How to run
```
$YOUR_INSTALLATION_PATH/kube-ci/kube-ci/kube-ci.sh -b -p=test -bi=1
```

## Requirements

### Docker image
   
    Docker image URL
   
### Manual requirements
    
    - Git
    - Kubectl
    - GCloud
    - Bash
    - shyaml
#!/usr/bin/env bash
tar -cf kube-ci.tar . 
